import pygame
from sys import exit
import os
from pygame.locals import *
import Game


class Pane(object):
    def __init__(self):
        pass


"""Button Class: Holds x, y, width. height, sprite, text"""
class Button(object):
    sprite = pygame.image.load("assets/img/sprite/MM_Button.png")

    GENERAL_BUTTON_X = (Game.WIN_WIDTH // 2) - (sprite.get_size()[0] // 3) // 2
    GENERAL_BUTTON_HEIGHT = sprite.get_size()[1] // 3

    button_y_separator = 230

    def __init__(self, pos=(GENERAL_BUTTON_X, button_y_separator), text="Button", size_scale=3):
        Button.button_y_separator += Button.GENERAL_BUTTON_HEIGHT + 20
        tmp = Button.sprite.copy()
        self.button = pygame.transform.scale(tmp, (tmp.get_size()[0] // size_scale, tmp.get_size()[1] // size_scale))
        self.x = pos[0]
        self.y = pos[1]
        self.size_scale = size_scale
        font = pygame.font.Font("assets/font/BebasNeue.otf", 60)
        self.text_width, self.text_height = font.size(text)
        self.text_surface = font.render(text, True, (255, 255, 255))

    def set_scale(self, scale):
        tmp = self.button.sprite.copy()
        self.button = pygame.transform.scale(tmp, (tmp.get_size()[0] // scale, tmp.get_size()[1] // scale))


def display_text(text, font_location, size):
    fnt_text = pygame.font.Font(font_location, int(size))
    txt_surface = fnt_text.render(text, True, (255, 255, 255))
    return txt_surface

# Init PyGame
pygame.init()
pygame.mixer.init()
pygame.font.init()
DISPLAYSURF = pygame.display.set_mode((Game.WIN_WIDTH, Game.WIN_WIDTH))
t = pygame.image.load("assets/img/ico/tent.ico")
pygame.display.set_icon(t)
pygame.display.set_caption("Carnival")
clock = pygame.time.Clock()

# Init Images
button_play = pygame.image.load("assets/img/sprite/MM_Button.png")
banner = pygame.image.load("assets/img/sprite/MM_Banner.png")
bg = pygame.image.load("assets/img/bg-img/MM-BG-Blur.jpg")
button_highscore = pygame.image.load("assets/img/sprite/HS_Button.png")

# Move Images
banner = pygame.transform.scale(banner, (banner.get_size()[0] // 3, banner.get_size()[1] // 3))
banner_x = (Game.WIN_WIDTH - banner.get_size()[0]) // 2
banner_y = 35

button_highscore_x = 550
button_highscore_y = 550

play_button = Button(text="PLAY")
options_button = Button((Button.GENERAL_BUTTON_X, Button.button_y_separator), "OPTIONS")
help_button = Button((Button.GENERAL_BUTTON_X, Button.button_y_separator), "HELP")
quit_button = Button((Button.GENERAL_BUTTON_X, Button.button_y_separator), "QUIT")

# Init Objects
msg = Game.Message()

# Init Music
pygame.mixer.pre_init(44100, -16, 2, 2048)
pygame.mixer.music.load("assets/aud/bg-music/bg.wav")
pygame.mixer.music.play(-1)

# Game Loop
while True:
    DISPLAYSURF.fill((0, 0, 0))
    msElapsed = clock.tick(Game.MENU_FPS)
    mouse_pos = pygame.mouse.get_pos()

    # Check for Events
    for event in pygame.event.get():
        if event.type == QUIT:
            # Exit PyGame and Python
            pygame.mixer.music.stop()
            pygame.mixer.quit()
            pygame.font.quit()
            pygame.quit()
            exit()
        if event.type == MOUSEBUTTONDOWN:
            x, y = event.pos

            if Game.rect_point_collide(play_button.button, (play_button.x, play_button.y), pygame.mouse.get_pos()):
                # Run Darts.py
                msg.debug("Collision: PLAY")
                msg.debug("Starting Darts.py")
                pygame.mixer.music.pause()
                os.system("python Darts.py")
                pygame.mixer.music.unpause()

            if Game.rect_point_collide(options_button.button, (options_button.x, options_button.y), pygame.mouse.get_pos()):
                msg.debug("Collision: OPTIONS")

            if Game.rect_point_collide(help_button.button, (help_button.x, help_button.y), pygame.mouse.get_pos()):
                msg.debug("Collision: HELP")
                msg.debug("Starting Help.py")
                os.system("python Help.py")

            if Game.rect_point_collide(quit_button.button, (quit_button.x, quit_button.y), pygame.mouse.get_pos()):
                msg.debug("Collision: QUIT")
                msg.debug("Quitting Game")
                pygame.mixer.music.stop()
                pygame.mixer.quit()
                pygame.font.quit()
                pygame.quit()
                exit()

            if Game.rect_point_collide(button_highscore, (button_highscore_x, button_highscore_y), pygame.mouse.get_pos()):
                msg.debug("Collision: HIGHSCORE")
                msg.debug("Starting HS.py")
                os.system("python HS.py")

    # Draw
    DISPLAYSURF.blit(bg, (0, 0))

    DISPLAYSURF.blit(display_text("FPS: " + str(msElapsed), "assets/font/BebasNeue.otf", 45), (550, 0))
    DISPLAYSURF.blit(display_text("Music by: Marc Jungermann, \"The Carousel\"", "assets/font/BebasNeue.otf", 20), (10, 625))

    DISPLAYSURF.blit(banner, (banner_x, 35))
    DISPLAYSURF.blit(play_button.button, (play_button.x, play_button.y))
    DISPLAYSURF.blit(options_button.button, (options_button.x, options_button.y))
    DISPLAYSURF.blit(help_button.button, (help_button.x, help_button.y))
    DISPLAYSURF.blit(quit_button.button, (quit_button.x, quit_button.y))
    DISPLAYSURF.blit(button_highscore, (button_highscore_x, button_highscore_y))

    DISPLAYSURF.blit(play_button.text_surface, (Game.WIN_WIDTH // 2 - play_button.text_width // 2, play_button.y))
    DISPLAYSURF.blit(options_button.text_surface, (Game.WIN_WIDTH // 2 - options_button.text_width // 2, options_button.y))
    DISPLAYSURF.blit(help_button.text_surface, (Game.WIN_WIDTH // 2 - help_button.text_width // 2, help_button.y))
    DISPLAYSURF.blit(quit_button.text_surface, (Game.WIN_WIDTH // 2 - quit_button.text_width // 2, quit_button.y))

    # Update display
    pygame.display.update()
