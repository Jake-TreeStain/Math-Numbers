import pygame
from sys import exit
from pygame.locals import *
import Game

def display_text(text, font_location, size, col=(255,255,255)):
    fnt_text = pygame.font.Font(font_location, int(size))
    txt_surface = fnt_text.render(text, True, (col))
    return txt_surface

# Init PyGame
pygame.init()
pygame.font.init()
DISPLAYSURF = pygame.display.set_mode((300, 300))
pygame.display.set_icon(pygame.image.load("assets/img/ico/tent.png"))
pygame.display.set_caption("Carnival Help")
clock = pygame.time.Clock()

# Init Images
bg = pygame.image.load("assets/img/bg-img/MM-BG-Blur.jpg")

# Init Objects
msg = Game.Message()

# Game Loop
while True:
    DISPLAYSURF.fill((0, 0, 0))
    msElapsed = clock.tick(Game.MENU_FPS)

    # Check for Events
    for event in pygame.event.get():
        if event.type == QUIT:
            # Exit PyGame and Python
            pygame.font.quit()
            pygame.quit()
            exit()


    # Draw
    DISPLAYSURF.blit(bg, (0, 0))

    DISPLAYSURF.blit(display_text("Darts: ", "assets/font/BebasNeue.otf", 30, (0, 0, 0)), (5, 0))
    DISPLAYSURF.blit(display_text("Click all the balloons, before they", "assets/font/BebasNeue.otf", 25), (5, 35))
    DISPLAYSURF.blit(display_text("get to the top, in 30 seconds.", "assets/font/BebasNeue.otf", 25), (5, 60))

    DISPLAYSURF.blit(display_text("Whack A Mole: ", "assets/font/BebasNeue.otf", 30, (0, 0, 0)), (5, 95))
    DISPLAYSURF.blit(display_text("Whack all the moles, before they", "assets/font/BebasNeue.otf", 25), (5, 130))
    DISPLAYSURF.blit(display_text("disappear, in 30 seconds.", "assets/font/BebasNeue.otf", 25), (5, 155))



    # Update display
    pygame.display.update()

