import pygame
from sys import exit
from pygame.locals import *
import Game
from random import randint

# Create Sprites


class Mole(object):
    sprite = pygame.image.load("assets/img/sprite/moles/mole.png")

    def __init__(self, alive_time_ms=3000, creation_time=0):
        self.x = randint(130, Game.WIN_WIDTH - 130)
        self.y = 510
        self.alive_time_ms = alive_time_ms
        self.creation_time = creation_time

    def __str__(self):
        return "mole, x:" + str(self.x) + ", y:" + str(self.y)


def display_text(text, font_location="assets/font/BebasNeue.otf", size=45, col=(255, 255, 255)):
    fnt_text = pygame.font.Font(font_location, int(size))
    txt_surface = fnt_text.render(text, True, col)
    return txt_surface

# Init PyGame
pygame.init()
pygame.mixer.init()
pygame.font.init()
DISPLAYSURF = pygame.display.set_mode((Game.WIN_WIDTH, Game.WIN_WIDTH))
pygame.display.set_caption("Carnival Whack-A-Mole")
clock = pygame.time.Clock()

# Init Images
bg = pygame.image.load("assets/img/bg-img/Darts-BG.jpg")

# Init Sound
pop = pygame.mixer.Sound("assets/aud/pop.ogg")

# Init Objects
msg = Game.Message()
tk = Game.TicketKeeper()
moles = [Mole(randint(500, randint(1000, 2000)), creation_time=0)]

# Init vars
moles_hit = 0
game_won = False
highscore = False

ms_time = 0

# Game Loop
while True:
    DISPLAYSURF.fill((0, 0, 0))
    msElapsed = clock.tick(Game.FPS)
    if not game_won:
        ms_time += msElapsed
    mouse_pos = pygame.mouse.get_pos()

    if ms_time > 31000:
        game_won = True
        if tk.check_score("WHACK") < moles_hit:
            msg.debug("Saving new highscore")
            tk.update("WHACK", moles_hit)
            tk.save()
            highscore = True

    if not game_won:
        if len(moles) < 6:
            if randint(1, randint(5, 75)) == 3:
                moles += [Mole(randint(500, randint(1000, 2000)), creation_time=ms_time)]
            pass

    # Check for Events
    for event in pygame.event.get():
        if event.type == QUIT:
            # Exit PyGame and Python
            msg.debug("Quitting Game")
            tk.save()
            pygame.mixer.quit()
            pygame.font.quit()
            pygame.quit()
            exit()
        if event.type == KEYDOWN and game_won:
            msg.debug("Quitting Game")
            tk.save()
            pygame.mixer.quit()
            pygame.font.quit()
            pygame.quit()
            exit()
        if event.type == MOUSEBUTTONDOWN:
            x, y = event.pos
            if not game_won and len(moles) > 0:
                for mol in moles:
                    if Game.rect_point_collide(mol.sprite, (mol.x, mol.y), (x, y)):
                        moles_hit += 1
                        pop.play()
                        msg.debug("Hit" + str(mol))
                        moles.remove(mol)
                        del mol
                        break

    DISPLAYSURF.blit(bg, (0, 0))
    # Draw
    if not game_won:
        for mol in moles:
            if mol.creation_time + mol.alive_time_ms <= ms_time:
                # TODO fix
                moles_hit -= 1
                del mol
            else:
                DISPLAYSURF.blit(mol.sprite, (mol.x, mol.y))

    DISPLAYSURF.blit(display_text("FPS: " + str(msElapsed)), (550, 0))
    DISPLAYSURF.blit(display_text("SCORE: " + str(moles_hit)), (0, 0))
    DISPLAYSURF.blit(display_text(str(ms_time // 1000) + " secs"), (275, 0))
    if game_won:
        font = pygame.font.Font("assets/font/BebasNeue.otf", 80)
        game_text_width, game_text_height = font.size("Game Over!")
        DISPLAYSURF.blit(display_text("Game Over!", size=80, col=(0, 0, 0)), (Game.WIN_WIDTH // 2 - game_text_width // 2, Game.WIN_HEIGHT // 2))
        if highscore:
            font = pygame.font.Font("assets/font/BebasNeue.otf", 60)
            high_text_width, high_text_height = font.size("NEW HIGHSCORE: " + str(moles_hit))
            DISPLAYSURF.blit(display_text("NEW HIGHSCORE: " + str(moles_hit), size=60, col=(0, 0, 0)), (Game.WIN_WIDTH // 2 - high_text_width // 2, Game.WIN_HEIGHT // 2 + 90))

    # Update display
    pygame.display.update()
