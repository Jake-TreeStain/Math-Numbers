import pygame
from sys import exit
from pygame.locals import *
import Game
from random import randint


#  Game Object, balloon, holds x, y, colour, surface
class Balloon(object):

    def __init__(self, colour="red-", speed=1):
    
        # Set the speed to the wanted y move divided by 2 plus 1
        self.speed = (speed // 2) + 1
        
        self.colour = colour
        
        # Load the surface with the correct colour
        self.balloon = pygame.image.load("assets/img/sprite/balloons/" + self.colour + "balloon.png")
        
        # Set random x in the bounds
        self.x = randint(130, Game.WIN_WIDTH - 130)
        
        # Set y to bottom of screen
        self.y = 500
        
        # Set the size ratio
        ratio_div = randint(2, 4)
        
        # Resize the balloon with the new ratio
        self.balloon = pygame.transform.scale(self.balloon, (self.balloon.get_size()[0] // ratio_div, self.balloon.get_size()[1] // ratio_div))

    def __str__(self):
        return self.colour + "balloon, x:" + str(self.x) + ", y:" + str(self.y) + ", speed:" + str(self.speed)


# Define function to get the surface for text size, colour, font, and text
def display_text(text, font_location="assets/font/BebasNeue.otf", size=45, col=(255, 255, 255)):
    fnt_text = pygame.font.Font(font_location, int(size))
    txt_surface = fnt_text.render(text, True, col)
    return txt_surface

# Init PyGame
pygame.init()
pygame.mixer.init()
pygame.font.init()
DISPLAYSURF = pygame.display.set_mode((Game.WIN_WIDTH, Game.WIN_WIDTH))
pygame.display.set_caption("Carnival Darts")
clock = pygame.time.Clock()

# Init Images
bg = pygame.image.load("assets/img/bg-img/Darts-BG.jpg")
bg2 = pygame.image.load("assets/img/bg-img/Darts-BG2-test.png")

# Init Sound
pop = pygame.mixer.Sound("assets/aud/pop.ogg")

# Init Objects
msg = Game.Message()
tk = Game.TicketKeeper()
balloons = []
# White and blue balloons are to dark
colours = ["red-", "purple-", "cyan-", "yellow-", "green-"]

# Init vars
balloons_popped = 0
game_won = False
highscore = False

# Implement cheat for testing
cheat = False

ms_time = 0

# Game Loop
while True:
    DISPLAYSURF.fill((0, 0, 0))
    msElapsed = clock.tick(Game.FPS)
    if not game_won:
        ms_time += msElapsed
    mouse_pos = pygame.mouse.get_pos()

    if ms_time > 31000:
        game_won = True
        if tk.check_score("DARTS") < balloons_popped:
            msg.debug("Saving new highscore")
            tk.update("DARTS", balloons_popped)
            tk.save()
            highscore = True

    if not game_won:
        if len(balloons) < 6:
            if randint(1, randint(5, 75)) == 3:
                msg.debug("Balloon Created")
                balloons += [Balloon(colours[randint(0, len(colours) - 1)],
                                    randint((balloons_popped + 1) // 2,
                                            (balloons_popped + 1) * 2))]

    # Check for Events
    for event in pygame.event.get():
        if event.type == QUIT:
            # Exit PyGame and Python
            msg.debug("Quitting Game")
            tk.save()
            pygame.mixer.quit()
            pygame.font.quit()
            pygame.quit()
            exit()
        if event.type == KEYDOWN and game_won:
            msg.debug("Quitting Game")
            tk.save()
            pygame.mixer.quit()
            pygame.font.quit()
            pygame.quit()
            exit()
        if event.type == MOUSEBUTTONDOWN:
            x, y = event.pos
            if not game_won:
                for bal in balloons[::-1]:
                    if Game.rect_point_collide(bal.balloon, (bal.x, bal.y), (x, y)):
                        balloons_popped += 1
                        pop.play()
                        msg.debug("Popped " + str(bal))
                        balloons.remove(bal)
                        del bal
                        break

    DISPLAYSURF.blit(bg, (0, 0))
    # Draw
    if not game_won:
        for bal in balloons:
            if bal.y < (Game.WIN_HEIGHT - bg2.get_size()[1]) + 5:
                if balloons_popped > 0:
                    balloons_popped -= 1
                balloons.remove(bal)
                del bal
            else:
                bal.y -= bal.speed
                DISPLAYSURF.blit(bal.balloon, (bal.x, bal.y))

    font = pygame.font.Font("assets/font/BebasNeue.otf", 45)
    time_text_width, time_text_height = font.size(str(ms_time // 1000) + " secs")
    DISPLAYSURF.blit(bg2, (Game.WIN_WIDTH // 2 - bg2.get_size()[0] // 2, 75))
    DISPLAYSURF.blit(display_text("FPS: " + str(msElapsed)), (550, 0))
    DISPLAYSURF.blit(display_text("SCORE: " + str(balloons_popped)), (0, 0))
    DISPLAYSURF.blit(display_text(str(ms_time // 1000) + " secs"), (Game.WIN_WIDTH // 2 - time_text_width // 2, 0))
    if game_won:
        font = pygame.font.Font("assets/font/BebasNeue.otf", 80)
        game_text_width, game_text_height = font.size("Game Over!")
        DISPLAYSURF.blit(display_text("Game Over!", size=80, col=(0, 0, 0)),
                         (Game.WIN_WIDTH // 2 - game_text_width // 2, Game.WIN_HEIGHT // 2 - 100))
        press_any_key_msg = -10
        if highscore:
            font = pygame.font.Font("assets/font/BebasNeue.otf", 60)
            high_text_width, high_text_height = font.size("NEW HIGHSCORE: " + str(balloons_popped))
            DISPLAYSURF.blit(display_text("NEW HIGHSCORE: " + str(balloons_popped), size=60, col=(0, 0, 0)),
                             (Game.WIN_WIDTH // 2 - high_text_width // 2, Game.WIN_HEIGHT // 2 - 10))
            press_any_key_msg = 60
        font = pygame.font.Font("assets/font/BebasNeue.otf", 30)
        continue_text_width, continue_text_height = font.size("(Press any key to continue)")
        DISPLAYSURF.blit(display_text("(Press any key to continue)", size=30, col=(0, 0, 0)),
                         (Game.WIN_WIDTH // 2 - continue_text_width // 2, Game.WIN_HEIGHT // 2 + press_any_key_msg))

    # Update display
    pygame.display.update()
