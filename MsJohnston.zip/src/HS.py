import pygame
from sys import exit
from pygame.locals import *
import Game


def display_text(text, font_location, size):
    fnt_text = pygame.font.Font(font_location, int(size))
    txt_surface = fnt_text.render(text, True, (255, 255, 255))
    return txt_surface

# Init PyGame
pygame.init()
pygame.mixer.init()
pygame.font.init()
DISPLAYSURF = pygame.display.set_mode((300, 300))
pygame.display.set_caption("Carnival High Scores")
clock = pygame.time.Clock()

# Init Images

# Move Images
bg = pygame.image.load("assets/img/bg-img/MM-BG-Blur.jpg")
button_del = pygame.image.load("assets/img/sprite/Delete_Button.png")

# Init Sound

# Init Objects
msg = Game.Message()
tk = Game.TicketKeeper()

# Game Loop
while True:
    msElapsed = clock.tick(Game.FPS)

    # Check for Events
    for event in pygame.event.get():
        if event.type == QUIT:
            # Exit PyGame and Python
            msg.debug("Quitting Game")
            tk.save()
            pygame.mixer.quit()
            pygame.font.quit()
            pygame.quit()
            exit()
        if event.type == MOUSEBUTTONDOWN:
            pass

    DISPLAYSURF.blit(bg, (0, 0))

    button_y_separator = 0
    for name, score in tk.scores.items():
        DISPLAYSURF.blit(button_del, (250, button_y_separator + 5))
        DISPLAYSURF.blit(display_text(name + ": " + str(score), "assets/font/BebasNeue.otf", 45), (20, button_y_separator))
        button_y_separator += 50

    # Update display
    pygame.display.update()
