# Game Consts
WIN_WIDTH = 650
WIN_HEIGHT = 650
FPS = 30
MENU_FPS = 10


# Rectangle and point collision
def rect_point_collide(surf, surf_pos, point):
    if point[0] > surf_pos[0] < surf_pos[0] + surf.get_width() > point[0]:
        if point[1] > surf_pos[1] < surf_pos[1] + surf.get_height() > point[1]:
            return True
    return False


# Rectangle and rectangle collision
def rect_rect_collide(surf1, surf1_pos, surf2, surf2_pos):
    if surf2_pos[0] > surf1_pos[0] and surf2_pos[0] < surf1_pos[0] + surf1.get_width():
        if surf2_pos[1] > surf1_pos[1] and surf2_pos[1] < surf1_pos[1] + surf1.get_height():
            return True
    if surf1_pos[0] > surf2_pos[0] and surf1_pos[0] < surf2_pos[0] + surf2.get_width():
        if surf1_pos[1] > surf2_pos[1] and surf1_pos[1] < surf2_pos[1] + surf2.get_height():
            return True
    return False

	
def rect_rect_collide(surf1, surf1_pos, surf2, surf2_pos):
    pass

# Rectangle and Circle collision
def rect_circle_collide():
    pass


# Circle and circle collision
def circle_circle_collide():
    pass


# Point and point collision
def point_point_collide(point1, point2):
    if point1[0] == point2[0] and point1[1] == point2[1]:
        return True
    return False


# Score
class TicketKeeper(object):
    def __init__(self):
        self.sc_keep = open("usr.dat", "r+")
        
        # Holds dictionaries of game title : total score
        self.scores = {}
        
        # Load previous scores
        for line in self.sc_keep.readlines():
            self.scores[line.split(":")[0]] = int(line.split(":")[1].strip("\n"))
        self.sc_keep.close()

    # Saves score to text file usr.dat
    def save(self):
        self.sc_keep = open("usr.dat", "w")
        self.sc_keep.write("")
        self.sc_keep.close()

        self.sc_keep = open("usr.dat", "a")
        for name, score in self.scores.items():
            self.sc_keep.write(name + ":" + str(score) + "\n")

    def update(self, game, score):
        self.scores[game] = score

    def check_score(self, game):
        return self.scores[game]

    def clear_score(self, game):
        self.scores.pop(game)

    def clear_all_scores(self):
        self.scores.clear()


class Message(object):
    def __init__(self, err_show=True, deb_show=True):
        self.err_show = err_show
        self.deb_show = deb_show
        self.err_no = 0
        self.deb_no = 0

    def error(self, msg):
        self.err_no += 1
        if self.err_show:
            print("ERROR(" + str(self.err_no) + "):" + str(msg))

    def debug(self, msg):
        self.deb_no += 1
        if self.deb_show:
            print("DEBUG(" + str(self.deb_no) + "):" + str(msg))			
